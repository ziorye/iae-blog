let provinceDatas = []
for (i = 0; i < provinces.length; i++) {
    let pv = {
        value: provinces[i].count,
        name: provinces[i].province,
    }
    provinceDatas.push(pv);
}
// pie charts
// based on prepared DOM, initialize echarts instance
var provincePieChart = echarts.init(document.getElementById('provincePieChart'), 'light');

// specify chart configuration item and data
var option = {
    title: {
        text: '各省股票数量占比',
        subtext: '来源：用于演示的非实时数据',
        left: 'center',
        textStyle: {
            color: '#fff',
        },
        subtextStyle: {
            color: '#ccc',
        },
    },
    tooltip: {
        trigger: 'item',
        formatter: "{b}: {d}%"
    },
    series: [
        {
            name: '',
            type: 'pie',
            radius: '60%',
            label: {
                formatter: "{b} ({d}%)",
                show: false,
            },
            labelLayout: {
                hideOverlap: true,
            },
            data: provinceDatas,
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};

// use configuration item and data specified to show chart
provincePieChart.setOption(option);
