let datas = [];
let dataSse = [];
let dataSzse = [];
for (i = 0; i < stocks.length; i++) {
    let data = {
        lnglat: stocks[i].location.split(','),
        code_a: stocks[i].code_a,
        name: stocks[i].name,
        abbr_a: stocks[i].abbr_a,
        exchange: stocks[i].exchange,
        province: stocks[i].province,
        style: stocks[i].exchange === 'sse' ? 1 : 2,
    };

    if (data.exchange === 'sse') {
        dataSse.push(data)
    }

    if (data.exchange === 'szse') {
        dataSzse.push(data)
    }

    datas.push(data);
}
