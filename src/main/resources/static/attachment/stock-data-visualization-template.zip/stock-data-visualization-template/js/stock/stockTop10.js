let top10chart;
function drawTopValueChart(selectedOptionValue, selectedOptionText) {
    $.getJSON('https://default-sz.oss-cn-shenzhen.aliyuncs.com/api/stock/top10/' + selectedOptionValue.split('-')[0] + '/' + selectedOptionValue.split('-')[1] + '.json', function (result) {
        if (typeof(top10chart) == "undefined") {
            top10chart = echarts.init(document.getElementById('top10Chart'), 'light');
        }
        let top10Option = {
            title: {
                text: selectedOptionText + '总市值 TOP 10',
                subtext: '来源：用于演示的非实时数据',
                left: 'center',
                textStyle: {
                    color: '#fff',
                },
                subtextStyle: {
                    color: '#ccc',
                },
            },
            tooltip: {
                trigger: 'axis',
                formatter: '{b}<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:#0090ff"></span>总市值：{c} 亿元',
                axisPointer: {
                    type: 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                axisLabel: {
                    show: false,
                },
                splitLine: {
                    show: false,
                }
            },
            yAxis: {
                type: 'category',
                inverse: true,//倒叙
                data: result.yAxisData,
                axisLabel: {
                    color: '#ccc',
                }
            },
            series: [
                {
                    name: result.title,
                    type: 'bar',
                    emphasis: {
                        itemStyle: {
                            color: '#F472B6'
                        }
                    },
                    data: result.serieData
                }
            ]
        };
        top10chart.setOption(top10Option);
    });
}

let topTypeSelectedOption = $("#topType");
drawTopValueChart(topTypeSelectedOption.val(), topTypeSelectedOption.find("option:selected").text());
topTypeSelectedOption.change(function(){
    let selectedOptionValue = $(this).val();
    let selectedOptionText = topTypeSelectedOption.find("option:selected").text();
    drawTopValueChart(selectedOptionValue, selectedOptionText);
});
