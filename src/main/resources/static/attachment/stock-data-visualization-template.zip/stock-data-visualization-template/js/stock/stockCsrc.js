let csrcDatas = [];
let csrcDatasX = [];
let csrcDatasY = [];
for (i = 0; i < csrcs.length; i++) {
    let pv = {
        value: csrcs[i].count,
        name: csrcs[i].csrc_code,
    }
    csrcDatas.push(pv);
    csrcDatasX.push(csrcs[i].csrc_name)
    csrcDatasY.push(csrcs[i].count)
}
// based on prepared DOM, initialize echarts instance
var csrcChart = echarts.init(document.getElementById('csrc'), 'light');

// specify chart configuration item and data
var csrcOption = {
    title: {
        text: 'CSRC 行业分类统计',
        subtext: '来源：用于演示的非实时数据',
        textStyle: {
            color: '#fff',
        },
        subtextStyle: {
            color: '#ccc',
        },
        left: 'center',
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
    },
    xAxis: {
        type: 'category',
        data: csrcDatasX,
        axisLabel:{
            color: '#ccc',
            interval: 0,
            formatter: function (value) {
                //x轴的文字改为竖版显示
                var str = value.split("");
                return str.join("\n");
            }
        }
    },
    yAxis: {
        type: 'value',
        splitLine: {
            show: true,
            lineStyle: {
                // 使用深浅的间隔色
                color: ['#339ca8','#339ca8']
            }
        },
        axisLabel: {
            color: '#ccc',
        }
    },
    series: [{
        data: csrcDatasY,
        type: 'bar',
        /*markPoint: {
            data: [
                {type: 'max', name: '最大值'},
                {type: 'min', name: '最小值'}
            ]
        },*/
        /*itemStyle: {
            normal: {
                label: {
                    show: true,		//开启显示
                    position: 'top',	//在上方显示
                    rotate: 45,
                    textStyle: {	    //数值样式
                        color: 'white',
                        fontSize: 16
                    }
                }
            }
        },*/
        emphasis: {
            itemStyle: {
                color: '#F472B6'
            }
        }
    }]
};

// use configuration item and data specified to show chart
csrcChart.setOption(csrcOption);
