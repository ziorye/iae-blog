var g_Interval = 1;
var g_Timer;
var running = false;
$("#randomBtn").on('click', function () {
    if (running) {
        running = false;
        clearTimeout(g_Timer);
        $(this).val("随机选股");
    } else {
        running = true;
        $(this).val("停止");
        beginTimer();
    }
})

function beginTimer() {
    g_Timer = setTimeout(beat, g_Interval);
}

function beat() {
    g_Timer = setTimeout(beat, g_Interval);
    updateRndNum('sse', dataSse);
    updateRndNum('szse', dataSzse);
}

function updateRndNum(exchange, dataArray) {
    var index = Math.floor(Math.random() * (dataArray.length - 1));
    $('#code_a-' + exchange).html(dataArray[index].code_a);
    $('#abbr_a-' + exchange).html(dataArray[index].abbr_a);
}
