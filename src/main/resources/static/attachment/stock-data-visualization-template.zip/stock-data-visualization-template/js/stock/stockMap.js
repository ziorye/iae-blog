let mapDatasSse = [];
let mapDatasSzse = [];
for (i = 0; i < stocks.length; i++) {
    let dataValue = stocks[i].location.split(',');
    dataValue[2] = stocks[i].province;
    dataValue[3] = stocks[i].code_a;
    let data = {
        name: stocks[i].name,
        value: dataValue,
    }

    if (stocks[i].exchange === 'sse') {
        mapDatasSse.push(data);
    }

    if (stocks[i].exchange === 'szse') {
        mapDatasSzse.push(data);
    }
}
let mapChart;
$(function() {
    // ======================================================================
    // map charts
    // based on prepared DOM, initialize echarts instance
    mapChart = echarts.init(document.getElementById('mapContainer'), 'light');
    $.getJSON("https://default-sz.oss-cn-shenzhen.aliyuncs.com/api/china.json", function (china) {
        echarts.registerMap('china', china);
        // specify chart configuration item and data
        let mapChartOption = {
            title: {
                text: 'A股上市公司分布地图',
                subtext: '来源：用于演示的非实时数据',
                left: 'center',
                //show: false,
            },
            legend: {
                top: 'bottom',
                left: 'left',
                //icon: 'circle',
            },
            toolbox: {
                feature: {
                    restore: { // 配置项还原
                        show: true,
                    }
                }
            },
            // 自定义提示框内容
            tooltip: {
                //alwaysShowContent: true, // 提示框总是显示（不再是鼠标离开就消失）
                //enterable: true, // 允许提示框被点击
                formatter: function (params) {
                    let value = params.value;
                    return '所属省份：' + value[2] + '<br>公司名称：' + params.name + '<br>A 股代码：' + value[3];
                }
            },
            geo: {
                map: 'china', // 地图选择china，对应引入的china.js
                silent: true, // 禁止图形响应鼠标事件。【如果不禁止，可能出现：当鼠标移动到地图上的 scatter 散点会出现点重绘、闪烁的问题】
                roam: true, // 启用缩放和平移。
                zoom: 1.2,
                scaleLimit: { // 缩放极限
                    min: 1.0,
                },
                itemStyle: {
                    areaColor: 'rgb(147, 197, 253)', // 区域颜色
                    borderWidth: 0,
                    //borderColor: '#43d0d6', // 边框颜色
                },
                label: {
                    color: '#fff',
                    fontWeight: 'bold'
                },
                /*// emphasis 高亮状态下的多边形和标签样式。
                emphasis: {
                    focus: 'self',
                    itemStyle: {
                        areaColor: 'rgb(59, 130, 246)', // 区域颜色
                    },
                    label: {
                        color: '#fff',
                        fontWeight: 'bold'
                    },
                }*/
            },
            series: [
                {
                    type: 'scatter', //  指明图表类型：effectScatter=带涟漪效果的散点图
                    name: '上交所',
                    zlevel: 2, // 数值越大越靠上
                    coordinateSystem: 'geo', //  指明绘制在geo坐标系上
                    symbol: 'circle', // 标记的图形
                    symbolSize: 8, // 标记的大小
                    itemStyle: {
                        color: '#700002',
                    },
                    data: mapDatasSse
                },
                {
                    type: 'scatter',
                    name: '深交所',
                    zlevel: 1,
                    coordinateSystem: 'geo',
                    symbol: 'circle',
                    symbolSize: 8,
                    itemStyle: {
                        color: '#002b7a',
                    },
                    data: mapDatasSzse
                }
            ]
        };

        // use configuration item and data specified to show chart
        mapChart.setOption(mapChartOption);

        /*// 监听地图缩放和平移
        mapChart.on('georoam', function () {
            mapChart.setOption({
                toolbox: {
                    feature: {
                        restore: { // 配置项还原
                            show: true,
                        }
                    }
                },
            })
        })*/
    });
    // ======================================================================
});
