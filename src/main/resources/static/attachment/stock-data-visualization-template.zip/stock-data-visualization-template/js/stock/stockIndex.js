function in_time_range(beginTime, endTime) {
    var strb = beginTime.split(":");
    if (strb.length != 2) {
        return false;
    }
    var stre = endTime.split(":");
    if (stre.length != 2) {
        return false;
    }

    var b = new Date();
    var e = new Date();
    var n = new Date();

    b.setHours(strb[0]);
    b.setMinutes(strb[1]);
    e.setHours(stre[0]);
    e.setMinutes(stre[1]);

    if (n.getTime() - b.getTime() > 0 && n.getTime() - e.getTime() < 0) {
        return true;

    } else {
        return false;
    }
}

let sseTimer;
function getSseIndexData() {
    ['000001', '000688'].forEach(function (value, index, array) {
        $.getJSON('https://default-sz.oss-cn-shenzhen.aliyuncs.com/api/stock/index/sse/' + value + '.json', function(result){
            let color;
            //let now = parseFloat(result.snap[1]).toFixed(2);
            let now = result.snap[1];
            let delta = result.snap[3];
            let deltaPercent = result.snap[2];
            if (delta > 0) {
                color = 'red';
                delta = '+' + delta;
                deltaPercent = '(+' + deltaPercent + '%)';
                $('#index-now-' + result.code).css('color', color);
                $('#index-delta-' + result.code).css('color', color);
                $('#index-deltaPercent-' + result.code).css('color', color);
            } else if (delta < 0) {
                color = 'green';
                deltaPercent = '(' + deltaPercent + '%)';
                $('#index-now-' + result.code).css('color', color);
                $('#index-delta-' + result.code).css('color', color);
                $('#index-deltaPercent-' + result.code).css('color', color);
            } else {
                // delta == 0
                delta = '0.00'
                deltaPercent = '(0.00%)';
            }

            //$('#index-name-' + result.code).html(result.snap[0]); // name=result.snap[0]
            $('#index-now-' + result.code).html(now); // now
            $('#index-delta-' + result.code).html(delta); // delta
            $('#index-deltaPercent-' + result.code).html(deltaPercent); // deltaPercent
        });
    });

    if (in_time_range('9:30', '11:30') || in_time_range('13:30', '15:30')) {
        //console.log('in_time_range, sse')
        sseTimer = window.setTimeout("getSseIndexData()", 30*1000);
    }else {
        clearTimeout(sseTimer);
        sseTimer = 0;
        console.log('clear sseTimer')
    }
}

let szseTimer;
function getSzseIndexData() {
    ['399001', '399006'].forEach(function (value, index, array){
        $.getJSON('https://default-sz.oss-cn-shenzhen.aliyuncs.com/api/stock/index/szse/' + value + '.json', function(result){
            let color = '#F87171';
            //let now = parseFloat(result.data.now).toFixed(2);
            let now = result.data.now;
            let delta = result.data.delta;
            let deltaPercent = result.data.deltaPercent;
            if (delta > 0) {
                delta = '+' + delta;
                deltaPercent = '(+' + deltaPercent + '%)';

                color = 'red';
                $('#index-now-' + result.data.code).css('color', color);
                $('#index-delta-' + result.data.code).css('color', color);
                $('#index-deltaPercent-' + result.data.code).css('color', color);
            } else if (delta < 0) {
                deltaPercent = '(' + deltaPercent + '%)';
                color = 'green';

                $('#index-now-' + result.data.code).css('color', color);
                $('#index-delta-' + result.data.code).css('color', color);
                $('#index-deltaPercent-' + result.data.code).css('color', color);
            } else {
                // delta == 0
                deltaPercent = '(' + deltaPercent + '%)';
            }

            $('#index-name-' + result.data.code).html(result.data.name);
            $('#index-now-' + result.data.code).html(now);
            $('#index-delta-' + result.data.code).html(delta);
            $('#index-deltaPercent-' + result.data.code).html(deltaPercent);
        });
    });

    if (in_time_range('9:30', '11:30') || in_time_range('13:30', '15:30')) {
        //console.log('in_time_range, szse')
        szseTimer = window.setTimeout("getSzseIndexData()", 30*1000);
    }else {
        clearTimeout(szseTimer);
        szseTimer = 0;
        console.log('clear szseTimer')
    }
}

// getSseIndexData
sseTimer = window.setTimeout("getSseIndexData()", 200);
// getSzseIndexData
szseTimer = window.setTimeout("getSzseIndexData()", 300);
